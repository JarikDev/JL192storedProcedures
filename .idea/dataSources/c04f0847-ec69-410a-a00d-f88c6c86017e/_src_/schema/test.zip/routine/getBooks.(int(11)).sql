CREATE PROCEDURE getBooks(IN bookId INT)
  BEGIN
SELECT * from Books WHERE id = bookId;
END;
